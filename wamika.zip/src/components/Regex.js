// export const ValidEmail=new RegExp('/^[a-zA-Z0-9]+(?:[a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:[a-zA-Z0-9]+)*$/');

// export const ValidFirstName=new RegExp('/^[A-Za-z0-9]+$/')

// export const ValidLastName=new RegExp('/^[A-Za-z0-9]+$/')

// export const CountryCode=new RegExp('/^[A-Za-z0-9]+$/')

// export const PhoneNum=new RegExp('/^[0-9]+$/')

// export const BusinessNeed=new RegExp('/^[a-zA-Z0-9_.-]*$/')